package Intermediate.team7.ClassBuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassBuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
